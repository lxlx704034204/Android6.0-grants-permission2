package com.neu.qrcode.skill.constants;

/**
 * Created by neuyuandaima on 2016/1/7.
 */
public class Constants {
    public static final int RESTART_PREVIEW = 1;
    public static final int DECODE = 2;
    public static final int DECODE_FAILED = 3;
    public static final int DECODE_SUCCESSED = 4;
    public static final int QUIT = 5;
    public static final int RETURN_SCAN_RESULT = 6;
    public static final int PERMISSION_DENY = 7;
}
