package com.neu.contact.contact;

/**
 * Created by neu on 16/2/16.
 * 权限结果
 */
public interface PermissionResultCallback {
    //用户点击否定
    void denyPermission();

}
